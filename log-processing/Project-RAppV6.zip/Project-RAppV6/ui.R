library(shiny)
library(shinydashboard)
library(DT)
ui <- shinyUI(fluidPage(
      titlePanel("Demo"),
      
      selectInput("dataset", "Choose a dataset:",
                  choices = c("Book1", "Book2", "Book3")),
      br(),
      
      column(width=2,uiOutput("State")),
      column(width=2,uiOutput("Country")),
      column(width=2,uiOutput("Device")),
      
      actionButton("Submitted","Submit"),
      
      br(),
      br(),
      br(),
      br(),
      
      column(width=2,actionLink("Count_Key1","Count_Key1:0")), 
      column(width=2,actionLink("Count_Key2","Count_Key2:0")),
      column(width=2,actionLink("Count_Key3","Count_Key3:0")),
      column(width=2,actionLink("Count_Key4","Count_Key4:0")),
      
      br(),
      br(), 
      div(style="display: inline-block;vertical-align:top;text-align:center; width: 300px;",actionLink("Click",verbatimTextOutput("Counter"))),
      div(style="display: inline-block;vertical-align:top; width: 8px;",HTML("<br>")),
      downloadButton("downloadData", "Click Me"),
      br(),
      br(),
      br(),
      
      uiOutput("dt")
)
)