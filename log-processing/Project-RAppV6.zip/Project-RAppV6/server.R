library(shiny)
library(DT)
server = shinyServer(function(input,output,session){
  
  global <- reactiveValues(refresh = FALSE)
  global <- reactiveValues(refresh1 = FALSE)
  values <- reactiveValues(one=0,two=0,three=0,four=0)
  
  datasetInput <- reactive({
    switch(input$dataset,
           "Book1" = Book1,
           "Book2" = Book2,
           "Book3" = Book3)
  })
  
  output$Dataset1 <- renderDataTable({
    data=datasetInput()
  })
  
  output$State = renderUI({
    selectInput("State", "Select State:", datasetInput()$State,selectize = TRUE,multiple = T)
  })
  
  output$Country = renderUI({
    selectInput("Country", "Select Country:", datasetInput()$Country,selectize = TRUE,multiple = T)
  })
  
  output$Device = renderUI({
    selectInput("Device", "Select Device:", datasetInput()$device,selectize = TRUE,multiple = T)
  })
  
  FinalData <- reactive({
    filter = datasetInput()$State%in%input$State &
      datasetInput()$Country%in%input$Country &
      datasetInput()$device%in%input$Device
    DataFilter = subset(datasetInput(),filter)
  })
  
  observeEvent(input$Submitted,{
    output$Submitted = renderText(1)
    isolate(global$refresh <- FALSE)
    isolate(global$refresh1 <- FALSE)
    input$Submitted
    
    count_Key1 = sum(FinalData()$Key_1)
    label_Key1 = paste("count_Key1:",count_Key1)
    updateActionButton(session, "Count_Key1",label = label_Key1)
    
    count_Key2 = sum(FinalData()$Key_2)
    label_Key2 = paste("count_Key2:",count_Key2)
    updateActionButton(session, "Count_Key2",label = label_Key2)
    
    count_Key3 = sum(FinalData()$Key_3)
    label_Key3 = paste("count_Key3:",count_Key3)
    updateActionButton(session, "Count_Key3",label = label_Key3)
    
    count_Key4 = sum(FinalData()$Key_4)
    label_Key4 = paste("count_Key4:",count_Key4)
    updateActionButton(session, "Count_Key4",label = label_Key4)
  })
  
  output$Counter = renderText(
    {
      isolate(global$refresh <- FALSE)
      DataFilter1 = paste("Total Number of Records",nrow(FinalData()))
    }
  )
  
  observeEvent(input$Count_Key1,{
    isolate(global$refresh <- TRUE)
    values$one=1
    values$two=0
    values$three=0
    values$four=0
    output$Key_1 = DT::renderDataTable(
      {
        DataFilter = subset(FinalData(),Key_1>0)
      })
    
    output$dt <- renderUI({if(global$refresh == FALSE) return()
      dataTableOutput('Key_1')})
  })
  
  observeEvent(input$Count_Key2,{
    isolate(global$refresh <- TRUE)
    values$one=0
    values$two=1
    values$three=0
    values$four=0
    output$Key_2 = DT::renderDataTable({
      DataFilter = subset(FinalData(),Key_2>0)
    })
    output$dt <- renderUI({if(global$refresh == FALSE) return()
      dataTableOutput('Key_2')})
  })
  
  observeEvent(input$Count_Key3,{
    isolate(global$refresh <- TRUE)
    values$one=0
    values$two=0
    values$three=3
    values$four=0
    output$Key_3 = DT::renderDataTable({
      DataFilter = subset(FinalData(),Key_3>0)
    })
    output$dt <- renderUI({if(global$refresh == FALSE) return()
      dataTableOutput('Key_3')})
  })
  
  observeEvent(input$Count_Key4,{
    isolate(global$refresh <- TRUE)
    values$one=0
    values$two=0
    values$three=0
    values$four=4
    output$Key_4 = DT::renderDataTable({
      DataFilter = subset(FinalData(),Key_4>0)
    })
    output$dt <- renderUI({if(global$refresh == FALSE) return()
      dataTableOutput('Key_4')})
  })
  
  
  observeEvent(input$Click,{
    output$Clicked = renderText(1)
    isolate(global$refresh <- TRUE)
    values$one=0
    values$two=0
    values$three=0
    values$four=0
    output$Table = DT::renderDataTable(
      {
        input$Submitted
        DataFilter = FinalData()
      })
    output$dt <- renderUI({if(global$refresh == FALSE) return()
      dataTableOutput('Table')})
  })
  
  myout = reactive({
    if(values$one)
    {DataFilter = subset(FinalData(),Key_1>0)}
    else
      if(values$two)
      {DataFilter = subset(FinalData(),Key_2>0)}
    else
      if(values$three)
      {DataFilter = subset(FinalData(),Key_3>0)}
    else
      if(values$four)
      {DataFilter = subset(FinalData(),Key_4>0)}
    else
      DataFilter = FinalData()
  })
  
  
  output$downloadData <- downloadHandler(
    filename=function() {
      paste('data-', Sys.Date(), '.csv', sep='')
    },
    content = function(file) {
      write.csv(myout(),file)
    },
    contentType = "text/plain"
  )
})