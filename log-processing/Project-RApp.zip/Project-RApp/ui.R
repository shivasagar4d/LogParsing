library(shiny)
ui <- shinyUI(fluidPage(
  titlePanel("Demo"),
  sidebarLayout(
    sidebarPanel(
      selectInput("State", "Select State",Dataset1$State,selected = "Select State",selectize = TRUE),
      selectInput("Country", "Select Country",Dataset1$Country,selected = "Select Country",selectize = TRUE),
      selectInput("Device", "Select Device",Dataset1$device,selected = "Select Device",selectize = TRUE),
      textInput("Comment","Comments",value="",width = NULL,placeholder = NULL)
      ),
    mainPanel(verbatimTextOutput("Counter"),
              tableOutput("Table"))       


    ))
)