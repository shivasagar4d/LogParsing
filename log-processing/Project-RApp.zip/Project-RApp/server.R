library(shiny)
server = shinyServer(function(input,output){
  output$Counter = renderText(
    {
      filter = Dataset1$State==input$State &
        Dataset1$Country==input$Country &
        Dataset1$device==input$Device &
        Dataset1$comments1==input$Comment 
      DataFilter1 = paste("Total Number of Records",nrow(subset(Dataset1,
                          filter))
      )
    }
  )
  
  output$Table = renderTable(
    {
      filter = Dataset1$State==input$State &
               Dataset1$Country==input$Country &
               Dataset1$device==input$Device &
        Dataset1$comments1==input$Comment 
      DataFilter = subset(Dataset1,
                           filter
                           )
      
    }
  )
})