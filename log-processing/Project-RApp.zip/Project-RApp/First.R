library(shiny)
install.packages("shinydashboard")
library(shinydashboard)
Dataset1 = read.csv('Book1.csv')