library(shiny)
library(shinydashboard)
library(DT)
ui <- shinyUI(fluidPage(
      titlePanel("Demo"),

      selectInput("State", "Select State",Dataset1$State,selected = "Select State",selectize = TRUE),
      selectInput("Country", "Select Country",Dataset1$Country,selected = "Select Country",selectize = TRUE),
      selectInput("Device", "Select Device",Dataset1$device,selected = "Select Device",selectize = TRUE),
      selectInput("Comment","Select Comments",Dataset1$comments1,selected = NULL,selectize = TRUE),
        

      actionButton("Click",verbatimTextOutput("Counter"),width='400px',border=0),
      br(),
      br(),
      br(),
      
      uiOutput("dt")
    ))