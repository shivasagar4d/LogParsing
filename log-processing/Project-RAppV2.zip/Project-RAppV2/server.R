library(shiny)
library(DT)
server = shinyServer(function(input,output){
  
    global <- reactiveValues(refresh = FALSE)

    output$Counter = renderText(
    {
      output$Clicked = renderText(0)
      isolate(global$refresh <- FALSE)
      filter = Dataset1$State==input$State &
               Dataset1$Country==input$Country &
               Dataset1$device==input$Device &
               Dataset1$comments1==input$Comment 
      DataFilter1 = paste("Total Number of Records",nrow(subset(Dataset1,
                          filter)))
    }
    )
  
    observeEvent(input$Click,{
      output$Clicked = renderText(1)
      isolate(global$refresh <- TRUE)
      output$Table = DT::renderDataTable(
      {
      input$Click
      filter = Dataset1$State==input$State &
               Dataset1$Country==input$Country &
               Dataset1$device==input$Device &
      Dataset1$comments1==input$Comment
      DataFilter = subset(Dataset1,filter)
      })
    })
    
    recordcount = renderText(output$Clicked)
    
    output$dt <- renderUI({if(global$refresh == FALSE) return()
                          dataTableOutput('Table')})
})