getwd()
library(tm)
library("SnowballC")
setwd(" Driver path")

df_input=read.csv("Inputdata.csv",stringsAsFactors =FALSE )
df_input1=read.csv("Inputdata.csv",stringsAsFactors =FALSE )
input_str<-read.csv("input_match.csv",stringsAsFactors =FALSE )

Match_string<-input_str$Match_string
#df_input

single_word <- gsub(" ","",Match_string)


# Stemming

for(k in 1:NROW(Match_string)){
  
  df_input[,1]= gsub(Match_string[k],single_word[k],df_input[,1])
}

for (i in 1:nrow(df_input)){
  for(j in 2:NROW(Match_string)){
    df_input[i,j]=length(grep(single_word[j],unlist(strsplit(df_input[i,1]," ")), ignore.case= TRUE))
  }
}
for (n in 2:NROW(Match_string)){
  colnames(df_input)[n] <- Match_string[n]
  
}
df_input[,1] <- df_input1[,1]
write.csv(df_input,"output.csv")

