library(shiny)
library(shinydashboard)
library(DT)
ui <- shinyUI(fluidPage(
      titlePanel("Demo"),
      
      selectInput("dataset", "Choose a dataset:",
                  choices = c("Book1", "Book2", "Book3")),
      
      
      column(width=2,uiOutput("State")),
      column(width=2,uiOutput("Country")),
      column(width=2,uiOutput("Device")),
      column(width=2,uiOutput("Comments")),
      
      
      br(),
      br(),
      
      br(),
      br(), 
      div(style="display: inline-block;vertical-align:top; width: 300px;",actionLink("Click",verbatimTextOutput("Counter"))),
      div(style="display: inline-block;vertical-align:top; width: 8px;",HTML("<br>")),
      downloadButton("downloadData", "Click Me"),
      br(),
      br(),
      br(),
      
      uiOutput("dt")
    ))
