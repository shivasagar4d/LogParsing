library(shiny)
library(DT)
server = shinyServer(function(input,output){
  
    global <- reactiveValues(refresh = FALSE)
    
    datasetInput <- reactive({
      switch(input$dataset,
             "Book1" = Book1,
             "Book2" = Book2,
             "Book3" = Book3)
    })
    
    output$Dataset1 <- renderDataTable({
      data=datasetInput()
    })
    
    output$State = renderUI({
      selectInput("State", "Select State:", datasetInput()$State,selectize = TRUE,multiple = T)
    })

    output$Country = renderUI({
      selectInput("Country", "Select Country:", datasetInput()$Country,selectize = TRUE,multiple = T)
    })

    output$Device = renderUI({
      selectInput("Device", "Select Device:", datasetInput()$device,selectize = TRUE,multiple = T)
    })
    
    output$Comments = renderUI({
      selectInput("Comment", "Select Comments:", datasetInput()$comments1,selectize = TRUE,multiple = T)
    })
    
    output$Counter = renderText(
      {
        output$Clicked = renderText(0)
        isolate(global$refresh <- FALSE)
        filter = datasetInput()$State%in%input$State &
          datasetInput()$Country%in%input$Country &
          datasetInput()$device%in%input$Device &
          datasetInput()$comments1%in%input$Comment 
        DataFilter1 = paste("Total Number of Records",nrow(subset(datasetInput(),
                                                                  filter)))
      }
    )
    
    
    observeEvent(input$Click,{
      output$Clicked = renderText(1)
      isolate(global$refresh <- TRUE)
      output$Table = DT::renderDataTable(
        {
          input$Click
          filter = datasetInput()$State%in%input$State &
            datasetInput()$Country%in%input$Country &
            datasetInput()$device%in%input$Device &
            datasetInput()$comments1%in%input$Comment
          DataFilter = subset(datasetInput(),filter)
        })
  
    output$dt <- renderUI({if(global$refresh == FALSE) return()
                          dataTableOutput('Table')})
    
    
    })
    
    myout = reactive({
      filter = datasetInput()$State%in%input$State &
        datasetInput()$Country%in%input$Country &
        datasetInput()$device%in%input$Device &
        datasetInput()$comments1%in%input$Comment
      DataFilter = subset(datasetInput(),filter)
    })
    
    
    
    output$downloadData <- downloadHandler(
      filename=function() {
        paste('data-', Sys.Date(), '.csv', sep='')
      },
      content = function(file) {
        write.csv(myout(),file)
      },
      contentType = "text/plain"
    )
})